/**
 * Nome: Mariana Suellen Pereira de Souza RA: 818145754
 */

export interface Filme {
    nome: string;
    descricao: string;
}

export interface Genero {
    nome: string;
    genero: string;
}